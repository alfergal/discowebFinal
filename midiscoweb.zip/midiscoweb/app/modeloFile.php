<?php
include_once 'config.php';

function SubirFile($usuario, $tamaño, $datos, $plan, $tmp, $cantidad){

    if (checkArchivo($tamaño, $datos, $plan, $cantidad)) {
        if (is_dir($datos[1]) && is_writable($datos[1])) {
            if (move_uploaded_file($tmp, $datos[1] . '/' . $datos[0]) == true) {
                return true;
                
            }
        }
    }
    return false;
}


function checkArchivo($tamaño, $datos, $plan, $cantidad){
    $tamañoFin = $tamaño + $datos[3];

    switch ($plan) {
        case "Básico":
            if(($tamañoFin)< LIMITE_ESPACIO[0] && ($cantidad)<LIMITE_FICHEROS[0]) 
                return true;
            break;
        case "Profesional":
            if(($tamañoFin)< LIMITE_ESPACIO[1] && ($cantidad)<LIMITE_FICHEROS[1]) 
                return true;
            break;
        case "Premium":
            if(($tamañoFin)< LIMITE_ESPACIO[2] && ($cantidad)<LIMITE_FICHEROS[2]) 
                return true;
            break;
        case "Máster":
            if(($tamañoFin)< LIMITE_ESPACIO[3] && ($cantidad)<LIMITE_FICHEROS[3]) 
                
                return true;
            break;
    }
}