<?php
// --------------------------------------------------------------
// Controlador que realiza la gestión de ficheros de un usuario
// ---------------------------------------------------------------
include_once 'config.php';
include_once 'Encriptador.php';
include_once 'modeloUserDB.php';
include_once 'modeloFile.php';

function ctlFileVerFicheros(){
    $_SESSION['modo'] = GESTIONFICHEROS;
    $arrayficheros = [];
    $nfiles=0;
    $tamañototal = 0;
    $directorio = RUTA_FICHEROS."/".$_SESSION['user'];
    if (is_dir($directorio)){
        if ($dh = opendir($directorio)){
            while (($fichero = readdir($dh)) !== false){
                $rutayfichero = $directorio.'/'.$fichero;
                if ( is_file($rutayfichero)){
                    $arrayficheros[$nfiles]['nombre'] = $fichero;
                    $arrayficheros[$nfiles]['tipo']   = mime_content_type($rutayfichero);
                    $tamaño = filesize($rutayfichero);
                    $arrayficheros[$nfiles]['tamaño'] = $tamaño;
                    $arrayficheros[$nfiles]['fecha']  =  date("d/m/Y",filectime ($rutayfichero));
                    $nfiles++;
                    $tamañototal += $tamaño;

                }
                $_SESSION['tamaño'] = $tamañototal;
                $_SESSION['cantidad'] = $nfiles;
            }
            closedir($dh);
        }
       
    }
    include_once 'plantilla/misArchivos.php';
}


function ctlFileNuevo(){

    $usuario = $_SESSION['user'];
    $tamaño = $_SESSION['tamaño'];
    $cantidad = $_SESSION['cantidad'];
    
    if (isset($_FILES['archivoSubir']['name'])) {
        
        $directorioSubir = RUTA_FICHEROS . "/" . $_SESSION["user"];
        $size = $_FILES['archivoSubir']['size'];
        $name = $_FILES['archivoSubir']['name'];
        $type = $_FILES['archivoSubir']['type'];
        $tmp = $_FILES['archivoSubir']['tmp_name'];
        $user = $_SESSION["user"];
        $plan = ModeloUserDB::ObtenerTipo($user);
        $estado = ModeloUserDB::ObtenerActividad($user);
        $datos = [
            $name,
            $directorioSubir,
            $type,
            $size
        ];
    if ($estado != 'B') {
            SubirFile($usuario, $tamaño, $datos, $plan, $tmp, $cantidad);
        }    
    
    ctlFileVerFicheros();
    }
}

function ctlFileBorrar(){
    $usuario = $_SESSION['user'];
	$nombre= RUTA_FICHEROS."/".$usuario."/".$_GET["archivo"];
    unlink($nombre);
    header('Location:index.php?operacion=VerFicheros');
}

function ctlFileRenombrar(){
    $usuario = $_SESSION['user'];
    $nombre = RUTA_FICHEROS."/".$usuario."/".$_GET["archivo"];
    $nombrenuevo = RUTA_FICHEROS."/".$usuario."/".$_GET["nuevo"];
    rename($nombre, $nombrenuevo);
    header('Location:index.php?operacion=VerFicheros');
}

function ctlFileCompartir(){
    $fichero = $_GET['nombre'];
    $usuario = $_SESSION['user'];
    $rutaArchivo= RUTA_FICHEROS."/".$usuario."/".$fichero;
    $rutaencriptada = Encriptador::encripta($rutaArchivo);
    
    // Genero la ruta de descarga
    if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on')
        $link = "https";
        else
        $link = "http";
    $link .= "://".$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];
    $link .="?operacion=DescargaDirecta&fdirecto=".html_entity_decode($rutaencriptada);
    echo "<script type='text/javascript'>alert('Fichero $fichero. Enlace de descarga:$link');".
          "document.location.href='index.php?operacion=VerFicheros';</script>";
}

function ctlFileDescargaDirecta(){
    if (!empty($_GET['fdirecto'])) {
        $rutaArchivo = Encriptador::desencripta($_GET['fdirecto']);    
        $pos = strrpos ( $rutaArchivo , "/");
        $fichero = substr($rutaArchivo,$pos+1);
        //echo "Se la solicitado descargar ruta: $rutaArchivo fichero: $fichero <br>";
        procesarDescarga($fichero,$rutaArchivo);
    }
}

function ctlFileDescargar(){
    $fichero = $_GET['nombre'];
    $usuario = $_SESSION['user'];
    $rutaArchivo= RUTA_FICHEROS."/".$usuario."/".$fichero;
    procesarDescarga($fichero, $rutaArchivo);
}

function procesarDescarga($fichero,$rutaArchivo){
    header('Content-Type: application/octet-stream');
    header("Content-Transfer-Encoding: Binary");
    header("Content-disposition: attachment; filename=$fichero");
    readfile($rutaArchivo);
}

function ctlFileModificarVu(){
    if ($_SERVER['REQUEST_METHOD'] == "POST") {
        $userdat = [];
        $userdat = [
            $_POST["nombre"],
            $_POST["email"],
            $_POST["clave1"],
            $_POST["plan"],
            'I',
            $_POST["clave2"]
        ];
            $user = $_POST['user'];
            $clave1 = $_POST["clave1"];
            $clave2 = $_POST["clave2"];
            $nombre = $_POST["nombre"];
            $email = $_POST["email"];
            $plan = $_POST["plan"];
            $estado = 'I';
        if(!ModeloUserDB::errorValoresModificar ($user, $clave1, $clave2, $nombre, $email, $plan, $estado)){
            ModeloUserDB::UserUpdate($user, $userdat);
        }
        
    }else{
        $user = $_GET['id'];
        $usuario = ModeloUserDB::UserGet($user);
        include_once 'plantilla/modificarVu.php';  
    }

    
}