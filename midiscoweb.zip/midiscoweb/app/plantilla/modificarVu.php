<?php

ob_start();

?>

<?php
$auto = $_SERVER['PHP_SELF'];

?>
<form id="form-modificar" action='index.php?operacion=Aceptar' method="POST">
	<label>Identificador</label><input class="cuadro" name="user" type="text" value="<?= $_GET['id'] ?>" disabled><br>
	<input class="cuadro-oculto" name="user" type="text" value="<?=  $usuario[0] ?>" hidden>
	<label>Nombre</label><input maxlength="20" class="cuadro" name="nombre" type="text" value="<?= $usuario[1] ?>"><br>
	<label>Correo electrónico</label><input class="cuadro" name="email" type="text" value="<?= $usuario[2] ?>"><br>
	<label>Contraseña</label><input maxlength="15" minlength="8" class="cuadro" name="clave1" type="password" value="<?= $usuario[5] ?>"><br>
	<label>Contraseña</label><input maxlength="15" minlength="8" class="cuadro" name="clave2" type="password" value="<?= $usuario[5] ?>"><br>
	<label>Plan</label>
	<select id="planes" name="plan">
			<option value='0' <?= ($usuario[3] == "Básico")?"selected":"" ?>>Básico</option>
			<option value='1' <?= ($usuario[3] == "Profesional")?"selected":"" ?>>Profesional</option>
			<option value='2' <?= ($usuario[3] == "Premium")?"selected":"" ?>>Premium</option>
			<option value='3' <?= ($usuario[3] == "Máster")?"selected":"" ?>>Máster</option>
	</select>

	<input class="boton-basico" type='submit' name='orden' value="Aceptar">
	<input class="boton-basico" type='submit' value='Cancelar'>
</form>

<?php

$contenido = ob_get_clean();
include_once "principal.php";
?>