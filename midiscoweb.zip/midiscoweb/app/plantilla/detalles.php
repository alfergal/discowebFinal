<?php

ob_start();
?>

<table id="tabla-detalles">
	<tr>
	<?php
	$auto = $_SERVER['PHP_SELF'];
	?>
	<tr>
		<th>Detalles</th><th>Usuario - <?= $usuario[0]  ?></th>
	</tr>
	<tr>
		<td>Nombre completo</td> <td><?= $usuario[1] ?></td>
	</tr>
	<tr>
		<td>Correo electrónico</td> <td><?= $usuario[2] ?></td>
	</tr>
	<tr>
		<td>Plan </td><td><?= $usuario[3] ?></td>
	</tr>
	<tr>
		<td>Estado </td><td><?= $usuario[4] ?></td>
	</tr>
	<tr>
		<td>Numero de ficheros </td><td><?= $_SESSION['cantidad']?> / <?=$_SESSION['cantidadMax'] ?> ( <?= round((($_SESSION['cantidad'] / $_SESSION['cantidadMax'] ) * 100), 2) ?> % )</td>
	</tr>
	<tr>
		<td>Espacio utilizado </td><td><?= $_SESSION['tamaño'] / 1000 ?>KB / <?= $_SESSION['tamañoMax'] / 1000 ?>KB ( <?= round((($_SESSION['tamaño'] / $_SESSION['tamañoMax'] ) * 100), 2) ?> % )</td>
	</tr>

</table>
<form action='index.php'>
	<input class="boton-basico" type='submit' value='Atrás'>
</form>

<?php
$contenido = ob_get_clean();
include_once "principal.php";
?>