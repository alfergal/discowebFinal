<?php ob_start(); ?>
<form action='index.php'>
	<input class="boton-basico" type='submit' name='orden' value='VerFicheros'>
</form>
<table id="tabla-usuarios">
	<tr>
<?php
$auto = $_SERVER['PHP_SELF'];
// identificador => Nombre, email, plan y Estado
?>
<?php foreach ($usuarios as $clave => $datosusuario) : ?>
<tr>		
<td class="celda"><?= $clave ?></td> 
	<?php for  ($j=0; $j < count($datosusuario); $j++) :?>
     <td class="celda"><?=$datosusuario[$j] ?></td>
	<?php endfor;?>
<td class="celda"><a href="#"
			onclick="confirmarBorrar('<?= $datosusuario[0]."','".$clave."'"?>);">Borrar</a></td>
<td class="celda"><a href="<?= $auto?>?orden=Modificar&id=<?= $clave ?>">Modificar</a></td>
<td class="celda"><a href="<?= $auto?>?orden=Detalles&id=<?= $clave?>">Detalles</a></td>
</tr>
<?php endforeach; ?>
</table>
<form action='index.php'>
	<input class="boton-basico" type='submit' name='orden' value='Cerrar'> 
	<input class="boton-basico" type='submit' name='orden' value="Registrarse"> 
</form>

<?php
// Vacio el bufer y lo copio a contenido
// Para que se muestre en div de contenido de la página principal
$contenido = ob_get_clean();
include_once "principal.php";

?>