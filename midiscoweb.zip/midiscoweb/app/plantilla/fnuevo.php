<?php
ob_start();

?>

<?php
$auto = $_SERVER['PHP_SELF'];

?>
<div id='aviso'><b><?= (isset($msg))?$msg:"" ?></b></div>
<form id="form-modificar" name='ALTA' method="POST" action="index.php?orden=Alta">
	
	<label>Usuario</label><input maxlength="10" minlength="5" class="cuadro" name="user" type="text" placeholder="Introduzca un usuario"><br>

	<label>Nombre</label><input maxlength="20" class="cuadro" name="nombre" type="text" placeholder="Introduzca nombre y apellido"><br>

	<label>Correo electrónico</label><input class="cuadro" name="email" type="text" placeholder="Introduzca una dirección de correo"><br>

	<label>Contraseña</label><input maxlength="15" minlength="8" class="cuadro" name="clave1" type="password" placeholder="Introduzca la contraseña"><br>

	<label>Repita contraseña</label><input maxlength="15" minlength="8" class="cuadro" name="clave2" type="password" placeholder="Introduzca la contraseña"><br>

	<br>
	<label>Plan</label>
		<select id="planes" name="plan">
			<option value='0'>Básico</option>
			<option value='1'>Profesional</option>
			<option value='2'>Premium</option>
			<option value='3'>Máster</option>		
		</select>
	<br>

	<input class="boton-basico" type='submit' name='orden' value="Alta">
	
</form>
<?php 
// Vacio el bufer y lo copio a contenido
// Para que se muestre en div de contenido
$contenido = ob_get_clean();
include_once "principal.php";

?>