<?php ob_start(); ?>
<form action='index.php?operacion=Nuevo' method="post" enctype="multipart/form-data">
	<input type='file' name='archivoSubir'>
	<input class="boton-basico" type="submit">
</form>

<table id="tabla-archivos">
	<tr>
		<th>Nombre</th>
		<th>Fecha</th>
		<th>Tamaño</th>
		<th>Tipo</th>
		<th colspan="3">Operaciones</th>
	</tr>
	<tr>
		<?php
		$auto = $_SERVER['PHP_SELF'];
		?>
		<?php foreach ($arrayficheros as $clave => $elemento) : ?>		
			<td class="celda">
				<?= $arrayficheros[$clave]['nombre'] ?>
			</td> 
		    <td class="celda"> 
		     	<?=$arrayficheros[$clave]['tipo'] ?>
			</td>
		    <td class="celda"> 
		     	<?=$arrayficheros[$clave]['tamaño'] ?>
			</td>
		    <td class="celda"> 
		     	<?=$arrayficheros[$clave]['fecha'] ?>
			</td>

		<td class="celda">
			<a onclick="confirmarBorrarArchivo('<?= $arrayficheros[$clave]['nombre']."','".$_SESSION['user']."'"?>);" ><img id="papelera" src="web/img/papelera.png" title="Borrar"></a>
		</td>
		<td class="celda">
			<a onclick="cambiarNombre('<?= $arrayficheros[$clave]['nombre']."','".$_SESSION['user']."'"?>);" ><img id="corregir" src="web/img/corregir.png" title="Renombrar"></a>
		</td>
		<td class="celda"> 
			<a onclick="compartir('<?= $arrayficheros[$clave]['nombre']."','".$_SESSION['user']."'"?>);" ><img id="compartir" src="web/img/compartir.png" title="Compartir">
			</a>
		</td>
	</tr>
		<?php endforeach; ?>
</table>
<a id="quitarEstilo" href="<?= $auto?>?operacion=Cambiarme&id=<?= $_SESSION['user'] ?>"><button class="boton-basico">Cambiar</button></a>
<form action='index.php'>
	<input class="boton-basico" type='submit' name='operacion' value='Atrás'>
	<input class="boton-basico" type='submit' name='operacion' value='Cerrar'> 
	
</form>

<?php
$contenido = ob_get_clean();
include_once "principal.php";
?>