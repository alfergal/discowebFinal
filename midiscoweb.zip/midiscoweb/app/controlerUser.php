<?php
// ------------------------------------------------
// Controlador que realiza la gestión de usuarios
// ------------------------------------------------
include_once 'config.php';
include_once 'modeloUserDB.php';

/*
 * Inicio Muestra o procesa el formulario (POST)
 */

function  ctlUserInicio(){
    $msg = "";
    $user ="";
    $clave ="";
    if ( $_SERVER['REQUEST_METHOD'] == "POST"){
        if (isset($_POST['user']) && isset($_POST['clave'])){
            $user = $_POST['user'];
            $clave= $_POST['clave'];

            if (modeloUserDB::OkUser($user,$clave)){
                $_SESSION['user'] = $user;

                $_SESSION['tipouser'] = modeloUserDB::ObtenerTipo($user);
                
                if (modeloUserDB::ObtenerActividad($user) != "Inactivo") {
                    if ($_SESSION['tipouser'] == "Máster"){
                        $_SESSION['modo'] = GESTIONUSUARIOS;
                        header('Location:index.php?orden=VerUsuarios');
                    }else {
                        $_SESSION['modo'] = GESTIONFICHEROS;
                        header('Location:index.php?orden=VerFicheros');
                    }
                }else{
                    $msg="Error: usuario no activado, espere la activación del administrador!";
                }
            }else {
                $msg="Error: usuario y contraseña no válidos.";
           }  
        }
    }
    
    include_once 'plantilla/facceso.php';
}


function ctlUserRegistroUsuario(){
    include_once 'plantilla/fnuevo.php';
}

function ctlUserNuevo(){
    include_once 'plantilla/fnuevo.php';
}

function ctlUserDetalles(){

    $usuario = modeloUserDB::UserGet($_GET['id']);
    modeloUserDB::tamañoOcupado($_GET['id']);

    include_once 'plantilla/detalles.php';
}

function ctlUserAtras(){
    if ($_SESSION['tipouser'] == 'Máster') {
        $_SESSION['modo'] = GESTIONUSUARIOS;
        ctlUserVerUsuarios ();
    }else{
        ctlUserCerrar();
    }

}

function ctlUserAlta(){
    $user = $_POST['user'];
    $clave1 = $_POST["clave1"];
    $clave2 = $_POST["clave2"];
    $nombre = $_POST["nombre"];
    $email = $_POST["email"];
    $plan = $_POST["plan"];
    $estado = 'I';
    if(!modeloUserDB::errorValoresAlta ($user, $clave1, $clave2, $nombre, $email, $plan, $estado)){
        $userid = $_POST['user'];
        $userdat = [];
        $userdat = [
            $_POST["nombre"],
            $_POST["email"],
            $_POST["clave1"],
            $_POST["plan"],
            'I'
        ];
        modeloUserDB::UserAdd($userid, $userdat);
        include_once 'plantilla/facceso.php';    
    }else{
        ctlUserRegistroUsuario();
    }

}

function ctlUserModificar(){

    if ($_SERVER['REQUEST_METHOD'] == "POST") {
        $userdat = [];
        $userdat = [
            $_POST["nombre"],
            $_POST["email"],
            $_POST["clave1"],
            $_POST["plan"],
            $_POST["estado"],
            $_POST["clave2"]
        ];
            $user = $_POST['user'];
            $clave1 = $_POST["clave1"];
            $clave2 = $_POST["clave2"];
            $nombre = $_POST["nombre"];
            $email = $_POST["email"];
            $plan = $_POST["plan"];
            $estado = $_POST["estado"];

        if(!ModeloUserDB::errorValoresModificar ($user, $clave1, $clave2, $nombre, $email, $plan, $estado)){
            ModeloUserDB::UserUpdate($user, $userdat);
        }
        
        
    }else{
        $user = $_GET['id'];
        $usuario = modelouserdb::UserGet($user);
        include_once 'plantilla/modificar.php';  
    }

    
}

function ctlUserAceptar(){
    $userdat = [];
    $userid = $_POST['user'];
    $userdat = [
        $_POST["nombre"],
        $_POST["email"],
        $_POST["clave1"],
        $_POST["plan"],
        $_POST["estado"]
    ];

    modeloUserDB::UserUpdate($userid, $userdat);
    ctlUserVerUsuarios();

}

function ctlUserBorrar()
{
    $user = $_GET['id'];
    ModeloUserDB::UserDel($user);
    ctlUserVerUsuarios ();
}

// Cierra la sesión y vuelva los datos
function ctlUserCerrar()
{
    session_destroy();
    ModeloUserDB::closeDB();
    // modeloUserSave();
    header('Location:index.php');
}

// Muestro la tabla con los usuario 
function ctlUserVerUsuarios (){
    // Obtengo los datos del modelo
    $usuarios = modeloUserDB::GetAll();
    // Invoco la vista 
    include_once 'plantilla/verusuariosp.php';
   
}
