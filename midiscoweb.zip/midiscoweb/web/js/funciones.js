function confirmarBorrar(nombre,id){
    if (confirm("¿Quieres eliminar el usuario:  "+nombre+"?"))
    {
        window.location.href="?orden=Borrar&id="+id;
    }
}

function confirmarBorrarArchivo(archivo,usuario){
    if (confirm("¿Quieres eliminar el archivo:  "+archivo+"?"))
    {
        window.location.href="?operacion=Borrar&archivo="+archivo;
    }
}

function cambiarNombre(archivo,usuario){
    var nuevo = prompt("Introduzca el nuevo nombre", archivo);
    window.location.href="?operacion=Renombrar&nuevo="+nuevo+"&archivo="+archivo;
}



function desplegar(){
	document.getElementById('form-acceso').style.display="block";
	document.getElementById('desplegar').style.display="none";
	document.getElementById('plegar').style.display="block";
}

function plegar(){
	document.getElementById('form-acceso').style.display="none";
	document.getElementById('plegar').style.display="none";
	document.getElementById('desplegar').style.display="block";
}